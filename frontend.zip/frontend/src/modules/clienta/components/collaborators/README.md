# Composants Collaborateurs

Ce dossier contient tous les composants réutilisables pour la gestion des collaborateurs.

## 📦 Composants Disponibles

### 1. CollaboratorStats.vue

Affichage des statistiques sous forme de cartes.

**Usage:**

```vue
<CollaboratorStats
  :stats="{ total: 42, active: 38, inactive: 4 }"
  :sites-count="5"
/>
```

**Props:**

- `stats` (Object): `{ total: number, active: number, inactive: number }`
- `sitesCount` (Number): Nombre de sites

---

### 2. CollaboratorFormFields.vue

Tous les champs du formulaire de création/modification.

**Usage:**

```vue
<CollaboratorFormFields
  v-model="formData"
  :sites="sites"
  :user-type-options="userTypes"
  :edit-mode="false"
  @site-change="handleSiteChange"
/>
```

**Props:**

- `modelValue` (Object): Données du formulaire (v-model)
- `sites` (Array): Liste des sites disponibles
- `userTypeOptions` (Array): Options de type d'utilisateur
- `editMode` (Boolean): Mode édition ou création

**Événements:**

- `update:modelValue`: Mise à jour des données (v-model)
- `site-change`: Changement de site

---

### 3. CollaboratorTable.vue

Table de données avec recherche, tri et pagination.

**Usage:**

```vue
<CollaboratorTable
  :users="users"
  :loading="loading"
  @view="viewUser"
  @edit="editUser"
  @delete="confirmDelete"
/>
```

**Props:**

- `users` (Array): Liste des utilisateurs
- `loading` (Boolean): État de chargement

**Événements:**

- `view(user)`: Voir les détails
- `edit(user)`: Modifier l'utilisateur
- `delete(user)`: Supprimer l'utilisateur

**Fonctionnalités:**

- Recherche globale
- Tri par colonnes (nom, email, site, type, statut, rôle)
- Pagination (10 items/page)
- Actions rapides (icônes)

---

### 4. CollaboratorViewDialog.vue

Modal de visualisation des détails.

**Usage:**

```vue
<CollaboratorViewDialog v-model="showDialog" :user="selectedUser" />
```

**Props:**

- `modelValue` (Boolean): État d'ouverture du dialog (v-model)
- `user` (Object): Utilisateur à afficher

**Affichage:**

- Informations générales
- Permissions groupées par catégorie
- Statut actif/inactif
- Type d'utilisateur

---

### 5. PermissionSelector.vue

Sélection des permissions avec groupes.

**Usage:**

```vue
<PermissionSelector
  :selected-permissions="permissions"
  :suggested-permissions="suggestedPerms"
  :profile-label="'Collaborateur'"
  :profile-description="'Accès limité'"
  :permission-groups="groups"
  @apply-suggested="applyProfile"
  @select-all="selectAll"
  @toggle-permission="toggle"
/>
```

**Props:**

- `selectedPermissions` (Array): Permissions sélectionnées
- `suggestedPermissions` (Array): Permissions suggérées selon profil
- `profileLabel` (String): Nom du profil
- `profileDescription` (String): Description du profil
- `permissionGroups` (Array): Groupes de permissions

**Événements:**

- `apply-suggested`: Appliquer profil suggéré
- `select-all`: Tout sélectionner
- `deselect-all`: Tout désélectionner
- `select-group(groupId)`: Sélectionner un groupe
- `deselect-group(groupId)`: Désélectionner un groupe
- `toggle-permission(permission)`: Toggle une permission

---

## 🔧 Composable usePermissions

Logique centralisée pour la gestion des permissions.

**Usage:**

```typescript
import {
  usePermissions,
  permissionProfiles,
  permissionGroups,
} from "@/composables/usePermissions";

const {
  selectedPermissions,
  selectAll,
  deselectAll,
  selectGroup,
  deselectGroup,
  togglePermission,
  applySuggested,
} = usePermissions();

// Appliquer profil collaborateur
applySuggested(permissionProfiles.collaborator.permissions);

// Sélectionner groupe "Documents"
selectGroup("documents");
```

**Profils disponibles:**

- `collaborator`: 18 permissions de base
- `site_manager`: 34 permissions (+ gestion utilisateurs)

**Groupes disponibles:**

- Documents (4 permissions)
- Processus (3 permissions)
- Risques (7 permissions)
- Non-Conformités (5 permissions)
- Actions (4 permissions)
- Audits (4 permissions)
- Administration (4 permissions)

---

## 📝 Exemple Complet

```vue
<template>
  <div>
    <CollaboratorStats :stats="stats" :sites-count="sites.length" />

    <CollaboratorTable :users="users" :loading="loading" @edit="editUser" />

    <FormDialog v-model="dialog" title="Modifier collaborateur">
      <CollaboratorFormFields v-model="form" :sites="sites" :edit-mode="true" />

      <PermissionSelector
        :selected-permissions="selectedPermissions"
        :suggested-permissions="suggestedPermissions"
        :permission-groups="permissionGroups"
        @toggle-permission="togglePermission"
      />
    </FormDialog>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { usePermissions, permissionGroups } from "@/composables/usePermissions";
import CollaboratorStats from "./collaborators/CollaboratorStats.vue";
import CollaboratorTable from "./collaborators/CollaboratorTable.vue";
import CollaboratorFormFields from "./collaborators/CollaboratorFormFields.vue";
import PermissionSelector from "./collaborators/PermissionSelector.vue";

const { selectedPermissions, togglePermission } = usePermissions();

const stats = ref({ total: 42, active: 38, inactive: 4 });
const users = ref([]);
const sites = ref([]);
const form = ref({});
const dialog = ref(false);
const loading = ref(false);

function editUser(user) {
  form.value = { ...user };
  selectedPermissions.value = user.permissions.map((p) => p.name);
  dialog.value = true;
}
</script>
```

---

## 🎯 Avantages

1. **Réutilisabilité**: Chaque composant peut être utilisé indépendamment
2. **Maintenabilité**: Code modulaire facile à modifier
3. **Testabilité**: Composants isolés testables unitairement
4. **Performance**: Composants optimisés avec props reactives
5. **Cohérence**: Design system uniforme (Vuetify)

---

## 🔄 Migration

Si vous avez un ancien code monolithique, voici comment migrer:

**Avant (1127 lignes):**

```vue
<template>
  <!-- Tout dans un seul fichier -->
  <div>
    <!-- Stats -->
    <v-row>...</v-row>
    <!-- Table -->
    <v-data-table>...</v-data-table>
    <!-- Form -->
    <v-dialog>
      <v-text-field>...</v-text-field>
      <!-- ... 50 champs -->
    </v-dialog>
  </div>
</template>
```

**Après (413 lignes):**

```vue
<template>
  <div>
    <CollaboratorStats :stats="stats" />
    <CollaboratorTable :users="users" @edit="editUser" />
    <FormDialog v-model="dialog">
      <CollaboratorFormFields v-model="form" />
    </FormDialog>
  </div>
</template>
```

**Réduction: -63% de code**

---

**Créé:** 2 février 2026  
**Auteur:** BestQHSE Dev Team  
**Version:** 1.0.0
