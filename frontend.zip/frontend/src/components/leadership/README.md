# Composants Leadership Réutilisables

## 📦 Composants Créés

### 1. **LeadershipLayout.vue**
Wrapper principal avec gradient background et content shell
```vue
<LeadershipLayout>
  <!-- Contenu -->
</LeadershipLayout>
```

### 2. **HeroCard.vue**
En-tête de page avec icône, titre, badges
```vue
<HeroCard
  icon="mdi-shield-check"
  icon-color="blue"
  title="Politique QHSE"
  subtitle="Description"
  :badges="[
    { icon: 'mdi-check', text: 'Version 1.0', variant: 'primary' },
    { icon: 'mdi-update', text: 'Actif', variant: 'secondary' }
  ]"
>
  <template #actions>
    <button>Action</button>
  </template>
</HeroCard>
```

**Props:**
- `icon`: string (icône mdi)
- `iconColor`: 'blue' | 'teal' | 'pink'
- `title`: string
- `subtitle`: string
- `badges`: Badge[]

### 3. **ProgressCard.vue**
Carte de progression avec cercle SVG animé
```vue
<ProgressCard
  :completion="75"
  label="Progression"
  value="3/4 champs"
  last-saved="Il y a 2 min"
/>
```

**Props:**
- `completion`: number (0-100)
- `label`: string
- `value`: string
- `lastSaved`: string

### 4. **TabsContainer.vue**
Onglets avec v-model
```vue
<TabsContainer
  v-model="activeTab"
  :tabs="[
    { value: 'form', label: 'Formulaire', icon: 'mdi-form-select' },
    { value: 'preview', label: 'Aperçu', icon: 'mdi-eye' }
  ]"
/>
```

**Props:**
- `tabs`: Tab[]
- `modelValue`: string

**Events:**
- `update:modelValue`: (value: string)

### 5. **GlassCard.vue**
Carte avec effet glassmorphism
```vue
<GlassCard>
  <!-- Contenu -->
</GlassCard>
```

### 6. **ActionButtons.vue**
Boutons d'action primary/secondary
```vue
<ActionButtons
  primary-label="Suivant"
  primary-icon="mdi-arrow-right"
  :primary-disabled="!isValid"
  secondary-label="Réinitialiser"
  secondary-icon="mdi-refresh"
  @primary="handleNext"
  @secondary="handleReset"
/>
```

**Props:**
- `primaryLabel`: string
- `primaryIcon`: string (optionnel)
- `primaryDisabled`: boolean
- `secondaryLabel`: string
- `secondaryIcon`: string
- `showSecondary`: boolean

**Events:**
- `primary`: ()
- `secondary`: ()

## 🎨 Variantes de Couleurs

### Icon Colors
- `blue`: #5b8dd9 (Politique QHSE)
- `teal`: #14b8a6 (Organigramme)
- `pink`: #ec4899 (Rôles & Responsabilités)

## 📝 Exemple d'Utilisation Complète

```vue
<template>
  <LeadershipLayout>
    <HeroCard
      icon="mdi-shield-check"
      icon-color="blue"
      title="Politique QHSE"
      subtitle="Définissez votre politique"
      :badges="badges"
    >
      <template #actions>
        <button class="btn-primary">Action</button>
      </template>
    </HeroCard>

    <ProgressCard
      :completion="completion"
      label="Progression"
      :value="`${filled}/${total} champs`"
      :last-saved="lastSaved"
    />

    <TabsContainer v-model="activeTab" :tabs="tabs" />

    <GlassCard>
      <transition name="fade-slide" mode="out-in">
        <div v-if="activeTab === 'form'">
          <!-- Formulaire -->
          <ActionButtons
            primary-label="Aperçu"
            primary-icon="mdi-arrow-right"
            :primary-disabled="!isValid"
            secondary-label="Réinitialiser"
            @primary="activeTab = 'preview'"
            @secondary="reset"
          />
        </div>
        <div v-else>
          <!-- Aperçu -->
        </div>
      </transition>
    </GlassCard>
  </LeadershipLayout>
</template>
```

## ✅ Avantages

1. **Réutilisabilité**: Composants utilisables dans toutes les pages Leadership
2. **Maintenabilité**: Modification centralisée du style
3. **Cohérence**: Design uniforme sur toutes les pages
4. **Performance**: Composants légers et optimisés
5. **Lisibilité**: Code des pages réduit de 60%

## 🔄 Prochaines Étapes

Refactoriser les 3 pages existantes pour utiliser ces composants.
