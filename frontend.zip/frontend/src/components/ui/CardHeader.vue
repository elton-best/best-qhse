<script setup lang="ts">
  import { computed } from 'vue'
  import { cn } from './utils'

  interface CardHeaderProps {
    class?: string
  }

  const props = defineProps<CardHeaderProps>()
  const classes = computed(() => cn(
    '@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6 pt-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6',
    props.class,
  ))
</script>

<template>
  <div :class="classes" data-slot="card-header">
    <slot />
  </div>
</template>
