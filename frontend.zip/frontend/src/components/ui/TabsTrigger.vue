<script setup lang="ts">
  import { TabsTrigger } from 'radix-vue'
  import { cn } from './utils'

  defineOptions({
    name: 'TabsTrigger',
    inheritAttrs: false,
  })

  const props = defineProps<{
    class?: string
    value: string
    disabled?: boolean
  }>()
</script>

<template>
  <TabsTrigger
    v-bind="$attrs"
    :class="cn(
      'data-[state=active]:bg-card dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-xl border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*=\'size-\'])]:size-4',
      props.class
    )"
    data-slot="tabs-trigger"
    :disabled="disabled"
    :value="value"
  >
    <slot />
  </TabsTrigger>
</template>
