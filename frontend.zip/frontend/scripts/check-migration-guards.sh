#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

has_rg=0
if command -v rg >/dev/null 2>&1; then
  has_rg=1
fi

search() {
  local pattern="$1"
  shift
  if [[ $has_rg -eq 1 ]]; then
    rg -n "$pattern" "$@"
  else
    grep -RInE "$pattern" "$@"
  fi
}

echo "[check:migration] Verifying runtime /clienta routes are not reintroduced..."
if [[ $has_rg -eq 1 ]]; then
  search "/clienta/" src \
    -g '!**/*.md' \
    -g '!**/README*' \
    -g '!src/modules/clienta/utils/routeCanonicalizer.ts' \
    | rg -v "@/modules/clienta/|from '@/modules/clienta|from \"@/modules/clienta" \
    >/tmp/check_migration_clienta.txt || true
else
  search "/clienta/" src \
    --exclude='*.md' \
    --exclude='README*' \
    | grep -Ev "^src/modules/clienta/utils/routeCanonicalizer.ts:" \
    | grep -Ev "@/modules/clienta/|from '@/modules/clienta|from \"@/modules/clienta" \
    >/tmp/check_migration_clienta.txt || true
fi
if [[ -s /tmp/check_migration_clienta.txt ]]; then
  echo "[check:migration] ERROR: found runtime /clienta references:"
  cat /tmp/check_migration_clienta.txt
  exit 1
fi

echo "[check:migration] Verifying legacy permission aliases are not reintroduced..."
if [[ $has_rg -eq 1 ]]; then
  search "['\"][a-z0-9_]+\\.(view|edit)['\"]|['\"](action\\.read|audit\\.read|process\\.read|non_conformities\\.read)['\"]" src \
    -g '!src/utils/permissions.ts' >/tmp/check_migration_permissions.txt || true
else
  search "['\"][a-z0-9_]+\\.(view|edit)['\"]|['\"](action\\.read|audit\\.read|process\\.read|non_conformities\\.read)['\"]" src \
    --exclude='permissions.ts' >/tmp/check_migration_permissions.txt || true
fi
if [[ -s /tmp/check_migration_permissions.txt ]]; then
  echo "[check:migration] ERROR: found legacy permission aliases:"
  cat /tmp/check_migration_permissions.txt
  exit 1
fi

echo "[check:migration] Verifying direct axios imports are not reintroduced..."
if [[ $has_rg -eq 1 ]]; then
  search "import axios|from 'axios'|from \"axios\"" src \
    -g '!src/api/client.ts' \
    -g '!src/api/http-client.ts' >/tmp/check_migration_axios.txt || true
else
  search "import axios|from 'axios'|from \"axios\"" src \
    --exclude='client.ts' \
    --exclude='http-client.ts' >/tmp/check_migration_axios.txt || true
fi
if [[ -s /tmp/check_migration_axios.txt ]]; then
  echo "[check:migration] ERROR: found direct axios imports outside API client layer:"
  cat /tmp/check_migration_axios.txt
  exit 1
fi

echo "[check:migration] Verifying http-client is only used by src/api/client.ts..."
if [[ $has_rg -eq 1 ]]; then
  search "from '@/api/http-client'|from './http-client'" src \
    -g '!src/api/client.ts' >/tmp/check_migration_http_client.txt || true
else
  search "from '@/api/http-client'|from './http-client'" src \
    --exclude='client.ts' >/tmp/check_migration_http_client.txt || true
fi
if [[ -s /tmp/check_migration_http_client.txt ]]; then
  echo "[check:migration] ERROR: found http-client imports outside src/api/client.ts:"
  cat /tmp/check_migration_http_client.txt
  exit 1
fi

echo "[check:migration] Verifying deleted legacy placeholder pages are not reintroduced..."
LEGACY_PAGE_FILES=(
  "src/modules/clienta/pages/AuditManagement.vue"
  "src/modules/clienta/pages/DocumentManagement.vue"
  "src/modules/clienta/pages/NonConformityManagement.vue"
  "src/modules/clienta/pages/ProcessManagement.vue"
  "src/modules/clienta/pages/RiskManagement.vue"
  "src/modules/clienta/pages/SubscriptionManagement.vue"
  "src/modules/clienta/pages/subscriptions/index.vue"
  "src/modules/clienta/pages/processes.old/index.vue"
  "src/modules/clienta/pages/processes.old/create.vue"
  "src/modules/clienta/pages/processes.old/[id].vue"
)

for legacy_file in "${LEGACY_PAGE_FILES[@]}"; do
  if [[ -f "$legacy_file" ]]; then
    echo "[check:migration] ERROR: legacy page reintroduced: $legacy_file"
    exit 1
  fi
done

echo "[check:migration] Verifying placeholder legacy migration markers are not reintroduced..."
if [[ $has_rg -eq 1 ]]; then
  search "Page legacy à migrer vers" src >/tmp/check_migration_legacy_markers.txt || true
else
  search "Page legacy à migrer vers" src >/tmp/check_migration_legacy_markers.txt || true
fi
if [[ -s /tmp/check_migration_legacy_markers.txt ]]; then
  echo "[check:migration] ERROR: found legacy placeholder markers:"
  cat /tmp/check_migration_legacy_markers.txt
  exit 1
fi

echo "[check:migration] OK"
